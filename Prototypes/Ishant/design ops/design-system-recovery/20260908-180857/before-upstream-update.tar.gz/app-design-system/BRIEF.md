# Titan design system brief

Source: ../index.html and its existing SVG/PNG asset folders. This shell is the
first source of evidence, not proof of rules shared by every Titan product.

Direction: preserve the existing dense desktop email layout, dark navigation,
light reading surfaces, restrained blue actions, compact typography and small radii.

Initial scope: attach the studio, inventory the design, adopt existing root tokens
without value changes, and establish an incremental enrichment plan. Keep component
and composition catalogs empty until contracts and states have been reviewed.

Proposed review viewports: 1440×900, 1280×800 and 768×900. Narrow-screen behavior is
unverified; do not claim mobile support. Preserve compose/reply, selection, search,
menus, settings and dock behavior. Use fictional data in new examples.

Do not redesign the shell, normalize exceptions, introduce themes, or extract whole
panes as components during setup. Keep original screen and asset paths in place.

Phase 2a: user authorized color/type foundations. Adopt existing values only;
visual approval and spacing remain separate checkpoints. See decisions/color-typography.md.

Color/type appearance accepted by the user. Phase 2b authorizes value-preserving
spacing extraction; component extraction and density changes remain out of scope.

## Product scope and browsing

This is the beginning of the broader Titan design system, not a one-screen email
DS. TitanEmailShell was the first reference. Future user-selected screens/features
will enrich the same system; each extraction needs its own evidence and source.
The current attachment path is a storage location, not a product-scope boundary.
Do not relocate content or expand the server filesystem root without a concrete
new source requirement. Selected sections fill the sidebar's remaining workspace;
only Overview retains an introductory header. Avoid repeated source-screen CTAs.
