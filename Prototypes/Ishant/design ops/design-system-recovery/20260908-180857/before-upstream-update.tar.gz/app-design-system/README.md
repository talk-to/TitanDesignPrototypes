# Titan design system

A growing cross-screen Titan catalog. ../index.html is its first reference,
not the boundary of the system. Start with AGENTS.md,
BRIEF.md, ROADMAP.md and decisions/initial-extraction.md.

From the Titan Design Git repository root:

```sh
node "Prototypes/Ishant/design system/studio.js" start --config Shells/TitanEmailShell/app-design-system/studio.config.json --port 8031
node "Prototypes/Ishant/design system/studio.js" check --config Shells/TitanEmailShell/app-design-system/studio.config.json
```

Open http://localhost:8031/#overview for the sidebar workbench.
Use Foundations → Colors, Typography or Spacing to browse in place; Screens opens
the source previews. /app/index.html remains the shell.
The studio checkout remains independently updatable. This folder belongs to the
Titan repository. No components have been promoted yet. See ROADMAP.md for stages.

The sidebar presentation is a local studio software change requested by the user.
Preserve these workbench edits before a future upstream update; the checked updater
will detect local changes. App tokens and the shell are unaffected by that UI change.
