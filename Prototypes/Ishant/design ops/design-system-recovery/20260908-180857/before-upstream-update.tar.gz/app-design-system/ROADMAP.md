# Titan design-system enrichment

Work in small reviewable passes. Each pass records evidence, decisions, remaining
gaps and verification. Catalog size is not a success measure.

| Step | Scope | Exit checkpoint |
| --- | --- | --- |
| 1. Connect and baseline | Attach existing shell, register its preview, move existing root controls unchanged, record inventory. | Source/import validation passes; visual baseline review pending. |
| 2. Foundations | Review color roles, typography, spacing, radii, borders, elevation and motion. Add only scales supported by evidence; migrate one property family at a time. | Foundation specimens and shell match at desktop/narrow widths; exceptions documented. |
| 3. States and assets | Inventory icons; document hover, pressed, selected, focus, disabled, loading and empty states where applicable. | Original assets mapped; keyboard and state gaps explicit; no invented states marked supported. |
| 4. A few primitives | Start with action/icon button, then basic/split action only if the existing uses support a common contract. One family per pass. | Real shared implementation adopted by shell, states/anatomy/specimen verified, no duplicated preview implementation. |
| 5. Repeated patterns | Consider menu rows, navigation items and message rows after comparing multiple actual uses. | Shared behavior and optional parts established; screen arrangement remains local. |
| 6. Broader adoption | Apply to a second selected Titan screen and refine only proven common contracts. | Both screens preserve appearance/behavior; ownership and exceptions stay clear. |

Now: color/type appearance is accepted by the user. Phase 2b spacing extraction
is implemented and ready for review; existing values and layout are preserved.
Agent visual/accessibility/responsive verification remains open. Next foundations:
radii, borders and elevation, after spacing review. Composer, reading pane, settings
and entire app layout remain compositions to study later, not early components.
Do not automatically execute all roadmap phases in a single task.
