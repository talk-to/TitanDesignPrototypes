# Decisions

Record evidence, scope, approved exceptions and verification here.
