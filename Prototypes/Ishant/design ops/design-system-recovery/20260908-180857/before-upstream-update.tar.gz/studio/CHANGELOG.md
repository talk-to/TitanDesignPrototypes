# Changelog

## Unreleased

- Use the full content workspace for selected sections; keep the introduction only on Overview and remove the repeated source-screen header.

- Replace the workbench presentation with a compact dark sidebar and catalog overview.
- Add nested foundation categories, alias-aware token previews, search and real counts.
- Keep source screens and existing component previews accessible through the sidebar.
- Add token parsing and navigation regression tests. Catalog contract v1 is unchanged.
- Local UI development only: framework version/lock are not regenerated for a release.


## 0.2.0 — plug-in studio and app-owned content

- Initialize against existing apps without an inbox, screen copying or relocation.
- Create a separate app DS folder once; repeat initialization preserves its content.
- Resolve configured content and existing screen URLs through shared server/validator mounts.
- Keep app boards, registries, tokens, specimens and local instructions outside the studio checkout.
- Load current shared agent instructions through an app-owned loader instead of frozen copies.
- Add checked Git software updates for the entire studio, including root UI/workflow files.
- Refuse dirty/divergent updates, overlapping folders and incompatible content contracts.
- Preserve v0.1 catalog and legacy startup compatibility; schema contract remains v1.
- Add regression tests for in-place attachment, isolated apps, safe serving and app-preserving updates.

## 0.1.0 — initial extraction

- Standalone localhost server and registry-driven eight-tab workbench.
- Empty project catalog separated from the fictional inspector sandbox.
- Extracted spacing/component inspector, stepper, shared/local scopes and copy prompts.
- Configurable registry/workbench URLs and reusable anatomy overlays.
- Reference controls, icons, chart renderers and screen pattern fixtures.
- Same-process persistent moodboard.
- Contract/source validation, regression tests and hash-checked framework releases.
- Retained original Titan DS snapshot for reference; no CRM database copied.
