(() => {
  'use strict';
  const tabs=[['overview','Overview','A place to define your design language, inspect real screens, and evolve the tools that keep them connected.'],['foundations','Foundations','Scales, semantic roles and component controls, read directly from the token source.'],['icons','Icons','Discover symbols through the project’s icon provider.'],['components','Components','Real implementations, anatomy, optional parts and states.'],['patterns','Patterns','Contracts for how tasks occupy a screen.'],['visualizations','Data visualization','Chart language, reading order and renderer examples.'],['directions','Directions','The same examples rendered with different semantic themes.'],['screens','Screens','Existing app screens and registered foundation specimens.'],['moodboard','Moodboard','Collect references and capture the decisions they inform.']];
  const $=id=>document.getElementById(id);
  const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let registry,profile,base,tokens=[],renderId=0;
  const groups=[['all','All foundations'],['colors','Colors'],['typography','Typography'],['spacing','Spacing'],['shape','Shape & elevation'],['motion','Motion'],['other','Other']];
  const source=relative=>new URL(relative,new URL(base,location.origin)).href;
  function safeURL(relative){const url=new URL(source(relative));if(url.origin!==location.origin)throw Error('Catalog URLs must be same-origin');return url;}
  function previewURL(entry,theme,inspect=false){const url=safeURL(entry.preview);if(theme)url.searchParams.set('theme',theme);if(inspect)url.searchParams.set('ds','true');return url.href;}
  const frame=(url,name,cls='preview')=>`<iframe class="${cls}" title="${esc(name)}" src="${esc(url)}" loading="lazy"></iframe>`;
  function card(entry,theme){
    const url=previewURL(entry,theme);
    return `<article class="card"><div class="card-head"><div><h2>${esc(entry.name)}</h2>${entry.class?`<code>${esc(entry.class)}</code>`:''}</div><span class="tag">${esc(entry.category||'CONTRACT')}</span></div>${entry.usage?`<p>${esc(entry.usage)}</p>`:''}<div class="width-tools" role="group" aria-label="Preview width"><button data-width="100%">Fluid</button><button data-width="320px">320px</button></div>${frame(url,entry.name)}<div class="actions"><a href="${esc(previewURL(entry,theme,true))}" target="_blank" rel="noopener">Inspect example ↗</a>${entry.css?`<a href="${esc(source(entry.css))}" target="_blank" rel="noopener">CSS source</a>`:''}${entry.module?`<a href="${esc(source(entry.module))}" target="_blank" rel="noopener">Renderer</a>`:''}</div><details><summary>Contract &amp; anatomy</summary><pre>${esc(JSON.stringify(entry,null,2))}</pre></details></article>`;
  }
  function empty(title){return `<div class="empty"><span class="empty-mark" aria-hidden="true">○</span><h2>${esc(title)}</h2><p>This section will fill as the design system grows. Existing foundations and screens are available from the sidebar.</p><a href="#foundations">Browse foundations →</a></div>`;}
  function count(tab){if(tab==='foundations')return tokens.length;if(tab==='components')return registry.components.length+registry.compositions.length;if(tab==='directions')return registry.themes.length;return registry[tab]?.length;}
  function navigation(active,group){
    const symbols={overview:'▤',foundations:'◇',icons:'⊞',components:'▣',patterns:'⌘',visualizations:'⌁',directions:'◐',screens:'▱',moodboard:'⊟'};
    $('catalog-nav').innerHTML=tabs.map(t=>`<a href="#${t[0]}" ${active===t[0]?'aria-current="page"':''}><span class="nav-icon" aria-hidden="true">${symbols[t[0]]}</span><span>${esc(t[1])}</span>${count(t[0])!==undefined?`<small>${count(t[0])}</small>`:''}</a>${t[0]==='foundations'&&active==='foundations'?`<div class="subnav">${groups.filter(g=>g[0]==='all'||tokens.some(t=>t.group===g[0])).map(g=>`<a href="#foundations/${g[0]}" ${group===g[0]?'aria-current="page"':''}>${g[1]}<small>${g[0]==='all'?tokens.length:tokens.filter(t=>t.group===g[0]).length}</small></a>`).join('')}</div>`:''}`).join('');
  }
  function overview(){
    const items=groups.filter(g=>g[0]!=='all'&&tokens.some(t=>t.group===g[0]));
    return `<div class="metric-row">${[[tokens.length,'Foundation declarations'],[registry.components.length+registry.compositions.length,'Components & compositions'],[registry.screens.length,'Registered previews']].map(([n,label])=>`<div class="metric"><strong>${n}</strong><span>${label}</span></div>`).join('')}</div><section class="catalog-table-wrap"><div class="section-heading"><h2>Explore the system</h2><span>Current catalog</span></div><table class="catalog-table"><thead><tr><th>Section</th><th>What’s inside</th><th>Entries</th></tr></thead><tbody>${items.map(g=>`<tr><th><a href="#foundations/${g[0]}"><span class="status-dot"></span>${g[1]}</a></th><td>Foundation tokens</td><td>${tokens.filter(t=>t.group===g[0]).length}</td></tr>`).join('')}${[['components','Components'],['icons','Icons'],['patterns','Patterns'],['screens','Screens']].map(([id,label])=>`<tr><th><a href="#${id}"><span class="status-dot ${count(id)?'':'pending'}"></span>${label}</a></th><td>${count(id)?'Registered in the catalog':'Not extracted yet'}</td><td>${count(id)}</td></tr>`).join('')}</tbody></table></section><p class="footnote">Counts reflect catalog entries and token declarations, not product adoption or verified states.</p>${registry.knownGaps?.length?`<details class="review-notes"><summary>Review notes <span>${registry.knownGaps.length}</span></summary><ul>${registry.knownGaps.map(g=>`<li>${esc(g)}</li>`).join('')}</ul></details>`:''}`;
  }
  function foundations(group){
    const rows=group==='all'?tokens:tokens.filter(t=>t.group===group);
    if(!rows.length)return empty('No foundations in this section yet');
    return `<div class="token-tools"><input type="search" aria-label="Filter tokens" placeholder="Search names, values or sources…" id="token-filter"><span id="result-count">${rows.length} entries</span></div><div class="token-table-wrap"><table class="token-table"><thead><tr><th>Preview</th><th>Token</th><th>Value</th><th>Source</th></tr></thead><tbody>${rows.map(r=>`<tr><td class="sample-cell"><span class="token-sample" data-kind="${r.group}" data-value="${esc(r.resolved)}" data-name="${esc(r.name)}">${r.group==='typography'?'Aa':r.group==='colors'?'':r.group==='spacing'?'':'—'}</span></td><th scope="row"><code>${esc(r.name)}</code>${r.value!==r.resolved?`<small>${esc(r.value)}</small>`:''}</th><td class="token-value"><code>${esc(r.resolved)}</code></td><td><a href="${esc(source(r.file))}" target="_blank" rel="noopener">${esc(r.file)}</a></td></tr>`).join('')}</tbody></table><p class="no-results" hidden>No matching tokens.</p></div><p class="footnote">Values come from the token source. Local or theme overrides in a screen may differ.</p>`;
  }
  async function render(){
    if(!registry)return;
    const id=++renderId,[route,requestedGroup]=location.hash.slice(1).split('/'),tab=tabs.find(t=>t[0]===route)||tabs[0];
    const group=groups.some(g=>g[0]===requestedGroup)?requestedGroup:'all';
    $('title').textContent=tab[1];$('intro').textContent=tab[2];$('eyebrow').textContent=(profile==='demo'?'TOOL DEVELOPMENT':'PROJECT DESIGN SYSTEM')+' / '+tab[1].toUpperCase();
    $('page-head').hidden=tab[0]!=='overview';
    $('main').className=tab[0]==='overview'?'view-overview':'view-content';
    $('main').ariaLabel=tab[0]==='foundations'&&group!=='all'?groups.find(g=>g[0]===group)[1]:tab[1];
    navigation(tab[0],group);
    if(tab[0]==='foundations'&&group!=='all')$('title').textContent=groups.find(g=>g[0]===group)[1];
    let html='';
    if(tab[0]==='overview'){
      $('title').textContent='Your design system, in one place.';
      $('intro').textContent='Browse the foundations, explore real screens, and grow the catalog one considered step at a time.';
      html=overview();
    }else if(tab[0]==='foundations'){
      html=foundations(group);
    }else if(tab[0]==='moodboard'){
      html='<div class="notice">References belong to the attached app’s content folder (or the standalone sandbox). Studio updates do not replace them. Profiles in this session share the board.</div>'+frame('/moodboard/','Reference moodboard','full-frame');
    }else if(tab[0]==='directions'){
      const entry=registry.screens[0]||registry.components[0];
      html=entry&&registry.themes.length?`<div class="grid">${registry.themes.map(theme=>`<article class="card"><h2>${esc(theme.name)}</h2><p>${esc(theme.description||'Semantic overrides')}</p>${frame(previewURL(entry,theme.id),theme.name,'preview tall')}<a class="source-link" href="${esc(source(theme.file))}">Theme source</a></article>`).join('')}</div>`:empty('No theme comparisons registered');
    }else{
      const entries=tab[0]==='components'?[...registry.compositions,...registry.components]:registry[tab[0]]||[];
      html=entries.length?`<div class="grid">${entries.map(entry=>card(entry)).join('')}</div>`:empty('No '+tab[1].toLowerCase()+' registered yet');
    }
    if(id!==renderId)return;$('content').innerHTML=html;
    $('token-filter')?.addEventListener('input',event=>{
      let visible=0;document.querySelectorAll('.token-table tbody tr').forEach(row=>{row.hidden=!row.textContent.toLowerCase().includes(event.target.value.toLowerCase());if(!row.hidden)visible++;});
      $('result-count').textContent=visible+' entries';document.querySelector('.no-results').hidden=visible!==0;
    });
    document.querySelectorAll('.token-sample').forEach(sample=>{
      const {kind,value,name}=sample.dataset;
      if(kind==='colors'&&CSS.supports('background-color',value))sample.style.backgroundColor=value;
      if(kind==='spacing'&&/^\d+(?:\.\d+)?px$/.test(value))sample.style.width=Math.min(parseFloat(value),80)+'px';
      if(kind==='typography'){
        if(/family|font-system/.test(name)&&CSS.supports('font-family',value))sample.style.fontFamily=value;
        else if(/weight/.test(name)&&CSS.supports('font-weight',value))sample.style.fontWeight=value;
        else if(/size/.test(name)&&/^\d+(?:\.\d+)?px$/.test(value))sample.style.fontSize=Math.min(parseFloat(value),32)+'px';
      }
    });
    document.querySelectorAll('[data-width]').forEach(button=>button.onclick=()=>{const iframe=button.closest('.card').querySelector('iframe');iframe.style.width=button.dataset.width;iframe.style.maxWidth='100%';});
  }
  async function load(){
    try{
      const config=await (await fetch('/api/studio')).json();
      profile=new URLSearchParams(location.search).get('profile')||config.defaultProfile;
      if(!['demo','project'].includes(profile))profile='project';
      base=profile==='demo'?'/demo/design-system/':'/design-system/';
      registry=await (await fetch(source('registry.json'))).json();
      const files=await Promise.all(registry.tokenFiles.map(async file=>{const response=await fetch(source(file));if(!response.ok)throw Error('Could not load '+file);return {file,text:await response.text()};}));
      tokens=studioTokens.parse(files);
      $('brand-name').textContent=registry.name.replace(/\s*design system$/i,'').trim()||'Studio';
      document.title=registry.name;
      $('catalog-summary').textContent=tokens.length+' foundations · '+(registry.components.length+registry.compositions.length)+' components';
      $('profile').value=profile;$('version').textContent='Framework '+config.version.version;
      $('profile').onchange=()=>{const url=new URL(location.href);url.searchParams.set('profile',$('profile').value);location.href=url.href;};
      await render();
    }catch(error){$('content').innerHTML='<div class="error">Could not load the catalog: '+esc(error.message)+'</div>';}
  }
  addEventListener('hashchange',()=>render().catch(error=>{$('content').textContent=error.message;}));load();
})();
