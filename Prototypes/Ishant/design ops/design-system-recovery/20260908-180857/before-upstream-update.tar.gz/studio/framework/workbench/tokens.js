(function(root){
  'use strict';
  function parse(files){
    const rows=files.flatMap(({file,text})=>Array.from(text.replace(/\/\*[\s\S]*?\*\//g,'' ).matchAll(/(--[\w-]+)\s*:\s*([^;{}]+);/g),m=>({name:m[1],value:m[2].trim(),file})));
    const definitions=new Map(rows.map(r=>[r.name,r.value]));
    function resolve(value,seen=new Set()){
      return value.replace(/var\((--[\w-]+)(?:,\s*([^()]+))?\)/g,(match,name,fallback)=>{
        if(seen.has(name))return match;
        if(!definitions.has(name))return fallback||match;
        return resolve(definitions.get(name),new Set([...seen,name]));
      });
    }
    return rows.map(row=>{
      const resolved=resolve(row.value,new Set([row.name]));
      const name=row.name.toLowerCase();let group='other';
      if(/^(?:#[\da-f]{3,8}\b|rgba?\(|hsla?\(|oklch\(|transparent$|white$|black$)/i.test(resolved))group='colors';
      else if(/font|type-|line-height|letter-spacing/.test(name))group='typography';
      else if(/radius|shadow|elevation/.test(name))group='shape';
      else if(/space|spacing|inset|padding|margin|gap/.test(name))group='spacing';
      else if(/motion|duration|ease|scale|transition/.test(name))group='motion';
      return {...row,resolved,group};
    });
  }
  const api={parse};if(typeof module==='object'&&module.exports)module.exports=api;else root.studioTokens=api;
})(typeof globalThis==='object'?globalThis:this);
